package ui;
import model.MenuOption;
import model.VideoGameController;
import java.util.Scanner;

public class VideoGameManager {
    static Scanner sc;
    static VideoGameController vgc;

    public static void main(String[] args) {
        init();
        showMenu();
    }
    
    public static void init() {
        System.out.println("Enter the resolution: ");
        int xLim = sc.nextInt();
        int yLim = sc.nextInt();
        sc = new Scanner(System.in);
        vgc = new VideoGameController(xLim, yLim);
        for(int i=0; i<10; i++) {
            vgc.addLevel(i);
        }
    }

    public static void showMenu() {
        int operation;
        boolean stop = false;
        while(!stop) {
            System.out.println("\nSelect the operation");
            System.out.println(vgc.showMenuOptions());

            System.out.print("\nOption: ");
            operation = sc.nextInt();

            switch(operation) {
                default:
                    System.out.println("Enter a valid option");
                    break;
            }
        }
    }

    public static void registerUser() {
        sc.nextLine();
        String id = "";
        do{
            System.out.print("Enter the id (this must be unique): ");
            id = sc.nextLine();
        } while(vgc.searchUser(id) != null || id.equals(""));

        System.out.print("Enter the name: ");
        String name = sc.nextLine();

        if(vgc.registerUser(id,name)) {
            System.out.println("\nUser added succesfully");
            System.out.println("\nUser list: ");
            System.out.println(vgc.showUsers());
        } else {
            System.out.println("\nUser list is full");
        } 
    }

    public static void registerEnemy() {
        System.out.print("Enter the name: ");
        String name = sc.nextLine();
        System.out.print("Enter the enemy type: ");
        System.out.println(vgc.showEnemyTypes());
        int type = sc.nextInt();
        System.out.print("Enter the score addition: ");
        double scoreAddition = sc.nextDouble();
        System.out.print("Enter the score substraction: ");
        double scoreSubstraction = sc.nextDouble();
        int level = -1;
        do{
            System.out.print("Enter the level id that you want to add the enemy to: ");
            level = sc.nextInt();
        } while(vgc.searchLevel(level) == null || level == -1);
        if(vgc.registerEnemy(name, type, scoreAddition, scoreSubstraction, level)) {
            System.out.println("Enemy registered successfully");
        } else {
            System.out.println("Enemy list of the given level is full or Enemy is already in level");
        }
    }

    public static void createTreasure() {
        System.out.print("Enter the name: ");
        System.out.print("Enter the picture url: ");
        System.out.print("ScoreReward: ");

    }

    public static void changeUserScore() {
        sc.nextLine();
        String id = "";
        do {
            System.out.print("Enter the user id: ");
            id = sc.nextLine();
        } while(vgc.searchUser(id) == null || id.equals(""));
        System.out.print("Enter the new score: ");
        double score = sc.nextDouble();
        if(vgc.changeUserScore(id, score)) {
            System.out.println("Score changed successfully");
        } else {
            System.out.println("User not found");
        }
    }
    public static void increaseUserLevel() {
        sc.nextLine();
        String id = "";
        do {
            System.out.print("Enter the user id: ");
            id = sc.nextLine();
        } while(vgc.searchUser(id) == null || id.equals(""));
        int level = -1;
        do { 
            System.out.print("Enter the new score: ");
            level = sc.nextInt();
        } while(vgc.searchLevel(level) == null || level == -1);
        double status = vgc.increaseUserLevel(id, level);
        if(status == -1) {
            System.out.println("Level increased successfully");
        } else {
            System.out.println("You need " + status + "points to increase to level " + level);
        }
    }
    public static void checkLevelObjects() {
        int level = -1;
        do { 
            System.out.print("Enter the new score: ");
            level = sc.nextInt();
        } while(vgc.searchLevel(level) == null || level == -1);
        System.out.println(vgc.checkLevelObjects(level));
    }
    public static void countTreasureName() {
        System.out.print("Enter the name: ");
        String name = sc.nextLine();
        System.out.println(vgc.countTreasureInLevels(name));
    }
    public static void countEnemyType() {
        System.out.print("Enter the name: ");
        int type = sc.nextInt();
        System.out.println(vgc.countEnemyInLevels(type));
    }
    public static void mostRepeatedTreasure() {
        System.out.println(vgc.mostRepeatedTreasure());
    }
}

package model;

public enum Difficulty {
    EASY, MEDIUM, HARD
}

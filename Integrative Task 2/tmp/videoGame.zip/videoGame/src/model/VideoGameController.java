package model;
import java.util.Random;

public class VideoGameController {
    private int xLim, yLim;
    private User[] users;
    private Level[] levels;
    private Treasure[] treasures;
    public VideoGameController(int xLim, int yLim) {
        this.users = new User[20];
        this.levels = new Level[10];
        this.treasures = new Treasure[500];
        this.xLim = xLim;
        this.yLim = yLim;
    }
    public String showMenuOptions() {
        String optionList = "";
        MenuOption[] options = MenuOption.values();
        for(int i=0; i<options.length; i++){
            optionList += "\n" + i + ". " + options[i];
        }
        return optionList;
    }
    public String showTreasures() {
        String treasureList = "";
        for(int i=0; i<treasures.length; i++) {
            if(treasures[i] != null) treasureList += "\n" + treasures[i].getName();
        }
        return treasureList;
    }
    public String showEnemyTypes() {
        String enemyList = "";
        EnemyType[] enemies = EnemyType.values();
        for(int i=0; i<enemies.length; i++) {
            enemyList += "\n" + (i+i) + ". " + enemies[i];
        }
        return enemyList;
    }
    public boolean addLevel(int index) {
        Level newLevel = new Level(index+1, (double)(100*(index+1)));
        for(int i=0; i<levels.length; i++) {
            if(levels[i] == null) {
                levels[i] = newLevel;
                return true;
            }
        }
        return false;
    }
    public boolean registerUser(String id, String name) {
        User newUser = new User(id, name);
        for(int i=0; i<users.length; i++) {
            if(users[i] == null) {
                users[i] = newUser;
                return true;
            }
        }
        return false;
    }
    public boolean registerEnemy(String name, int type, double scoreAddition, double scoreSubstraction, int level) {
        Enemy newEnemy = new Enemy(name, type, scoreAddition, scoreSubstraction, generatePosition());
        Level tmpLevel = searchLevel(level);
        if(tmpLevel.searchEnemy(name) != null) {
            return false;
        }
        if(tmpLevel.addEnemy(newEnemy)) {
            return true;
        }
        return false;
    }
    public boolean registerTreasure(String name, String picture, double scoreReward, int level, int timesInLevel) {
        Treasure newTreasure = new Treasure(name, picture, scoreReward, generatePosition(), timesInLevel);
        Level tmpLevel = searchLevel(level);
        if(tmpLevel.addTreasure(newTreasure)) {
            return true;
        }
        return false;
    }
    public String showUsers() {
        String userList = "";

        for(int i=0; i<users.length; i++) {
            if(users[i] != null) userList += "\n" + users[i].toString();
        }

        if(userList.equals("")) return "There are not users yet";

        return userList;
    }

    public boolean changeUserScore(String id, double score) {
        User tmpUser = searchUser(id);
        if(tmpUser == null) return false;
        tmpUser.setScore(score);
        return true;
    }
    public double increaseUserLevel(String id, int level) {
        User tmpUser = searchUser(id);
        Level tmpLevel = searchLevel(level);
        if(tmpUser.getScore() >= tmpLevel.getScoreLimit()) {
            tmpUser.setLevel(level);
            return -1;
        } else {
            return tmpLevel.getScoreLimit();
        }
    }
    public String checkLevelObjects(int level) {
        String objectList = "";
        Level tmpLevel = searchLevel(level);
        objectList += "\nEnemies: ";
        objectList += tmpLevel.showEnemies();
        objectList += "\nTreasures: ";
        objectList += tmpLevel.showTreasures();
        return objectList;
    }
    public String countTreasureInLevels(String name) {
        String treasureList = "";
        for(int i=0; i<levels.length; i++) {
            treasureList += "\n" + "Level " + (i+1) + ": " + levels[i].countTreasureName(name) + " treasures";
        }
        return treasureList;
    }
    public String countEnemyInLevels(int type){
        String enemyList = "";
        for(int i=0; i<levels.length; i++) {
            enemyList += "\n" + "Level " + (i+1) + ": " + levels[i].countEnemyType(type) + " enemies";
        }
        return enemyList;
    }
    public String mostRepeatedTreasure() {
        String treasureList = "none";
        for(int i=0; i<levels.length; i++) {
            Treasure tmpTreasure = levels[i].mostRepeatedTreasure();
            treasureList += "\n" + "Level " + (i+1) + ": " + tmpTreasure.getName() + "(" + tmpTreasure.getTimesInLevel() + " times)";
        }
        return treasureList;
    }
    /*
    public String showLevels() {
        String levelList = "";

        for(int i=0; i<levels.length; i++) {
            if(levels[i] != null) levelList += "\n" + levels[i].toString();
        }

        if(levelList.equals("")) return "There are not users yet";

        return levelList;
    }
    */

    public User searchUser(String id) {
        for(int i=0; i<users.length; i++) {
            if(users[i] != null && users[i].getId().equals(id)) return users[i];
        }
        return null;
    }
    public Level searchLevel(int id) {
        for(int i=0; i<levels.length; i++) {
            if(levels[i] != null && levels[i].getId() == id) return levels[i];
        }
        return null;
    }
    public int[] generatePosition() {
        Random rnd = new Random();
        int xPos = rnd.nextInt(xLim);
        int yPos = rnd.nextInt(yLim);
        int[] position = {xPos, yPos};
        return position;
    }
}

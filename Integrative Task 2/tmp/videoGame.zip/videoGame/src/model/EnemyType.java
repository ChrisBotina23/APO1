package model;

public enum EnemyType {
    OGRE,
    ABSTRACT,
    BOSS,
    MAGIC
}

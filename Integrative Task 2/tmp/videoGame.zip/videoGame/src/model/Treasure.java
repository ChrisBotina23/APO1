package model;
public class Treasure {
	private String name;
	private String picture;
	private double scoreReward;
	private int[] position;
    private int timesInLevel;
    public Treasure(String name, String picture, double scoreReward, int[] position, int timesInLevel) {
        this.name = name;
		this.picture = picture;
		this.scoreReward = scoreReward;
		this.position = position;
        this.timesInLevel = timesInLevel;
	}
    public int getTimesInLevel() {
        return timesInLevel;
    }
    public void setTimesInLevel(int timesInLevel) {
        this.timesInLevel = timesInLevel;
    }
	public String getName() {
		return this.name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPicture() {
		return this.picture;
	}
	public void setPicture(String picture) {
		this.picture = picture;
	}
	public double getScoreReward() {
		return this.scoreReward;
	}
	public void setScoreReward(double scoreReward) {
		this.scoreReward = scoreReward;
	}
	public int[] getPosition() {
		return this.position;
	}
	public void setPosition(int[] position) {
		this.position = position;
	}
	public String toString() {
		return "name: " + this.name 
        + ", picture: " + this.picture 
        + ", scoreReward: " + this.scoreReward 
        + ", position: (" + this.position[0] + "," + this.position[1] + ")";
	}
}

package model;
public class Enemy {
	private String name;    
	private EnemyType type;
    private double scoreAddition;
    private double scoreSubstraction;
	private int[] position;
	public Enemy(String name, int type, double scoreAddition, double scoreSubstraction, int[] position) {
        this.name = name;
		this.type = EnemyType.values()[type];
		this.scoreAddition = scoreAddition;
		this.position = position;
	}
    public EnemyType getType() {
        return type;
    }
    public void setType(EnemyType type) {
        this.type = type;
    }
	public String getName() {
		return this.name;
	}
	public void setName(String name) {
		this.name = name;
	}

	public double getScoreSubstraction() {
		return this.scoreSubstraction;
	}
	public void setScoreSubstraction(double scoreSubstraction) {
		this.scoreSubstraction = scoreSubstraction;
	}
	public double getScoreAddition() {
		return this.scoreAddition;
	}
	public void setScoreAddition(double scoreAddition) {
		this.scoreAddition = scoreAddition;
	}
	public int[] getPosition() {
		return this.position;
	}
	public void setPosition(int[] position) {
		this.position = position;
	}
	public String toString() {
		return "name: " + this.name 
        + ", picture: " + this.type 
        + ", scoreAddition: " + this.scoreAddition
        + ", scoreSubstraction: " + this.scoreSubstraction 
        + ", position: (" + this.position[0] + "," + this.position[1] + ")";
	}
}

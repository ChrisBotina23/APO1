package model;

public class Level {
    private int id;
    private double scoreLimit;
    private Difficulty difficulty;
    private Treasure[] treasures;
    private Enemy[] enemies;
    public Level(int id, double scoreLimit) {
        this.id = id;
        this.scoreLimit = scoreLimit;
        this.enemies = new Enemy[25];
        this.treasures = new Treasure[50];
        this.difficulty = Difficulty.MEDIUM;
    }
    public Difficulty getDifficulty() {
        return difficulty;
    }
    public void setDifficulty(Difficulty difficulty) {
        this.difficulty = difficulty;
    }
    public int getId() {
		return this.id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public double getScoreLimit() {
		return this.scoreLimit;
	}
	public void setScoreLimit(double scoreLimit) {
		this.scoreLimit = scoreLimit;
	}
    public boolean addEnemy(Enemy newEnemy) {
        for(int i=0; i<enemies.length; i++) {
            if(enemies[i] == null) {
                enemies[i] = newEnemy;
                calculateDiffiulty();
                return true;
            }
        }
        return false;
    }
    public Enemy searchEnemy(String name) {
        Enemy enemyMatch = null;
        for(int i=0; i<enemies.length; i++) {
            if(enemies[i].getName().equals(name)) return enemies[i];
        }
        return enemyMatch;
    }
    public Treasure searchTreasure(String name) {
        Treasure treasureMatch = null;
        for(int i=0; i<treasures.length; i++) {
            if(treasures[i].getName().equals(name)) return treasures[i];
        }
        return treasureMatch;
    }
    public boolean addTreasure(Treasure newTreasure) {
        for(int i=0; i<treasures.length; i++) {
            if(treasures[i] == null) {
                treasures[i] = newTreasure;
                calculateDiffiulty();
                return true;
            }
        }
        return false;
    }
    public String showEnemies() {
        String enemyList = "";
        for(int i=0; i<enemies.length; i++) {
            if(enemies[i] != null) enemyList += enemies[i].getName() + ",";
        }
        if(enemyList.equals("")) {
            return "There are not enemies in this level yet";
        } else {
            return enemyList;
        }
    }
    public String showTreasures() {
        String treasureList = "";
        for(int i=0; i<treasures.length; i++) {
            if(treasures[i] != null) treasureList += treasures[i].getName() + ",";
        }
        if(treasureList.equals("")) {
            return "There are not treasures in this level yet";
        } else {
            return treasureList;
        }
    }
    public int countTreasureName(String name) {
        int s = 0;
        for(int i=0; i<treasures.length; i++) {
            if(treasures[i] != null && treasures[i].getName().equals(name)) s++;
        }
        return s;
    }

    public int countEnemyType(int type) {
        int s = 0;
        for(int i=0; i<enemies.length; i++) {
            if(enemies[i] != null && EnemyType.values()[type] == enemies[i].getType()) s++;
        }
        return s;
    }
    public Treasure mostRepeatedTreasure() {
        Treasure maxTreasure = treasures[0];
        for(int i=0; i<treasures.length; i++) {
            if(treasures[i] != null && treasures[i].getTimesInLevel() > maxTreasure.getTimesInLevel()) maxTreasure = treasures[i];
        }
        return maxTreasure;
    }
    public void calculateDiffiulty() {
        int enemyScore = 0, treasureScore = 0;
        for(int i=0; i<enemies.length; i++) {
            if(enemies[i] != null) enemyScore += enemies[i].getScoreAddition();
        }
        for(int i=0; i<treasures.length; i++) {
            if(treasures[i] != null) treasureScore += treasures[i].getScoreReward();
        }

        if(enemyScore > treasureScore) {
            setDifficulty(Difficulty.HARD);
        } else if(enemyScore < treasureScore) {
            setDifficulty(Difficulty.EASY);
        } else {
            setDifficulty(Difficulty.MEDIUM);
        }
    }
    public String toString() {
		return "id: " + this.id 
        + ", scoreLimit: " + this.scoreLimit 
        + ", difficulty: " + this.difficulty; 
	}
}
package model;
public class User {
	private String id;
	private String name;
	private double score;
	private int level;
	public void setLevel(int level) {
		this.level = level;
	}
	public int getLevel() {
		return level;
	}
	private int lives;
	public User(String id, String name) {
		this.id = id;
		this.name = name;
		this.score = 10;
		this.lives = 5;
		this.level = 1;
	}
	public String getId() {
		return this.id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return this.name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getScore() {
		return this.score;
	}
	public void setScore(double score) {
		this.score = score;
	}
	public int getLives() {
		return this.lives;
	}
	public void setLives(int lives) {
		this.lives = lives;
	}
	public String toString() {
		return "id: " + this.id 
        + ", name: " + this.name 
        + ", score: " + this.score 
        + ", lives: " + this.lives;
	}
}
